# Responsive Student Portfolio and Academic Management Website

This project is a student portfolio website built for the COS 106 introduction to web technologies term project.

## Pages
- `index.html` – homepage
- `about.html` – biography and academic details
- `projects.html` – sample project gallery with filtering
- `planner.html` – interactive academic planner with localStorage
- `contact.html` – contact form with client-side validation

## File structure
- `css/style.css` – centralized styles and responsive design system
- `js/nav.js` – sidebar menu, animated skill bars and counters, typing effect, scroll reveal, photo lightbox (loaded on every page)
- `js/main.js` – project gallery rendering, filtering and details
- `js/planner.js` – task management logic and localStorage
- `js/contact.js` – client-side validation for contact form
- `assets/images` – placeholder images; see `assets/images/README.txt` for how to add your own photos
- `assets/media` – placeholder location for local multimedia files

## Notes
- Contact details and social links are editable placeholders.
- Project content is structured for easy updates.
- All pages are static and can be hosted on GitHub Pages or any static website host.
