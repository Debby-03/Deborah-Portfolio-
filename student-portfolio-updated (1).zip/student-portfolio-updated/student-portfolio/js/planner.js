const STORAGE_KEY = 'studentPortfolioTasks';

const defaultTasks = [
  {
    id: 'task-1',
    title: 'Revise COS 106 lecture notes',
    courseCode: 'COS 106',
    dueDate: '',
    priority: 'High',
    completed: false
  },
  {
    id: 'task-2',
    title: 'Practise HTML semantic elements',
    courseCode: 'COS 106',
    dueDate: '',
    priority: 'Medium',
    completed: false
  },
  {
    id: 'task-3',
    title: 'Study CSS Flexbox and Grid',
    courseCode: 'COS 106',
    dueDate: '',
    priority: 'High',
    completed: true
  },
  {
    id: 'task-4',
    title: 'Practise JavaScript form validation',
    courseCode: 'COS 106',
    dueDate: '',
    priority: 'Medium',
    completed: false
  },
  {
    id: 'task-5',
    title: 'Complete the COS 106 term project',
    courseCode: 'COS 106',
    dueDate: '',
    priority: 'High',
    completed: false
  },
  {
    id: 'task-6',
    title: 'Review SQL and data analytics exercises',
    courseCode: 'DATA 201',
    dueDate: '',
    priority: 'Medium',
    completed: false
  }
];

const form = document.querySelector('#task-form');
const titleInput = document.querySelector('#task-title');
const courseInput = document.querySelector('#course-code');
const dateInput = document.querySelector('#task-date');
const priorityInput = document.querySelector('#task-priority');
const feedback = document.querySelector('#task-feedback');
const taskList = document.querySelector('#task-list');
const filterButtons = document.querySelectorAll('.task-filter');

const totalTasksEl = document.querySelector('#total-tasks');
const pendingCountEl = document.querySelector('#pending-count');
const completedCountEl = document.querySelector('#completed-count');

let tasks = loadTasks();
let currentFilter = 'all';

function generateId() {
  if (window.crypto && typeof window.crypto.randomUUID === 'function') {
    return window.crypto.randomUUID();
  }
  return `task-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (error) {
    console.error('Unable to save planner tasks:', error);
    setFeedback('Unable to save tasks in this browser session.', 'error');
  }
}

function loadTasks() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [...defaultTasks];

    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return [...defaultTasks];
    }

    return parsed;
  } catch (error) {
    console.error('Invalid planner data detected. Reverting to defaults.', error);
    return [...defaultTasks];
  }
}

function setFeedback(message, type = 'success') {
  if (!feedback) return;
  feedback.textContent = message;
  feedback.className = `form-feedback ${type}`;
}

function updateTaskSummary() {
  const total = tasks.length;
  const completed = tasks.filter((task) => task.completed).length;
  const pending = total - completed;

  if (totalTasksEl) totalTasksEl.textContent = String(total);
  if (pendingCountEl) pendingCountEl.textContent = String(pending);
  if (completedCountEl) completedCountEl.textContent = String(completed);

  // Overall progress bar
  const percent = total === 0 ? 0 : Math.round((completed / total) * 100);
  const progressFill = document.querySelector('#progress-fill');
  const progressVal = document.querySelector('#progress-val');
  const progressTrack = document.querySelector('#progress-track');
  if (progressFill) progressFill.style.width = `${percent}%`;
  if (progressVal) progressVal.textContent = `${percent}%`;
  if (progressTrack) progressTrack.setAttribute('aria-valuenow', String(percent));
}

function filterTasks() {
  if (!taskList) return;

  const filteredTasks = tasks.filter((task) => {
    if (currentFilter === 'pending') return !task.completed;
    if (currentFilter === 'completed') return task.completed;
    return true;
  });

  taskList.innerHTML = '';

  if (filteredTasks.length === 0) {
    const emptyState = document.createElement('li');
    emptyState.className = 'task-item';
    emptyState.innerHTML = '<div class="task-content"><h3>No tasks match this filter.</h3></div>';
    taskList.appendChild(emptyState);
    return;
  }

  filteredTasks.forEach((task) => {
    const item = document.createElement('li');
    item.className = `task-item ${task.completed ? 'completed' : ''}`;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.className = 'task-check';
    checkbox.setAttribute('aria-label', `Mark ${task.title} as completed`);
    checkbox.addEventListener('change', () => toggleComplete(task.id));

    const content = document.createElement('div');
    content.className = 'task-content';

    const title = document.createElement('h3');
    title.className = 'task-title';
    title.textContent = task.title;

    const meta = document.createElement('div');
    meta.className = 'task-meta';

    if (task.courseCode) {
      const course = document.createElement('span');
      course.textContent = task.courseCode;
      meta.appendChild(course);
    }

    if (task.dueDate) {
      const due = document.createElement('span');
      due.textContent = `Due: ${task.dueDate}`;
      meta.appendChild(due);
    }

    const priority = document.createElement('span');
    priority.textContent = `Priority: ${task.priority}`;
    meta.appendChild(priority);

    content.append(title, meta);

    const actions = document.createElement('div');
    actions.className = 'task-actions';

    const toggleButton = document.createElement('button');
    toggleButton.type = 'button';
    toggleButton.textContent = task.completed ? 'Mark pending' : 'Mark complete';
    toggleButton.addEventListener('click', () => toggleComplete(task.id));

    const deleteButton = document.createElement('button');
    deleteButton.type = 'button';
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', () => deleteTask(task.id));

    actions.append(toggleButton, deleteButton);
    item.append(checkbox, content, actions);
    taskList.appendChild(item);
  });
}

function renderPlanner() {
  updateTaskSummary();
  filterTasks();
}

function addTask(event) {
  event.preventDefault();

  const title = titleInput.value.trim();
  if (!title) {
    setFeedback('Task title cannot be blank.', 'error');
    titleInput.focus();
    return;
  }

  const newTask = {
    id: generateId(),
    title,
    courseCode: courseInput.value.trim(),
    dueDate: dateInput.value,
    priority: priorityInput.value,
    completed: false
  };

  tasks.unshift(newTask);
  saveTasks();
  form.reset();
  priorityInput.value = 'Medium';
  setFeedback(`Task added: ${title}`, 'success');
  renderPlanner();
}

function toggleComplete(taskId) {
  tasks = tasks.map((task) => {
    if (task.id === taskId) {
      return { ...task, completed: !task.completed };
    }
    return task;
  });

  saveTasks();
  renderPlanner();
}

function deleteTask(taskId) {
  const task = tasks.find((item) => item.id === taskId);
  tasks = tasks.filter((item) => item.id !== taskId);
  saveTasks();
  setFeedback(task ? `Deleted: ${task.title}` : 'Task deleted.', 'success');
  renderPlanner();
}

if (form) {
  form.addEventListener('submit', addTask);
}

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    currentFilter = button.dataset.filter;
    filterButtons.forEach((btn) => btn.classList.toggle('active', btn === button));
    renderPlanner();
  });
});

renderPlanner();
