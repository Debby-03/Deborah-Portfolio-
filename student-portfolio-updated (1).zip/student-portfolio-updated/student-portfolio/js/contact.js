const contactForm = document.querySelector('#contact-form');

function clearFieldState(field) {
  const errorElement = document.querySelector(`#${field.id}-error`);
  field.setAttribute('aria-invalid', 'false');
  if (errorElement) {
    errorElement.textContent = '';
  }
}

function showFieldError(field, message) {
  const errorElement = document.querySelector(`#${field.id}-error`);
  field.setAttribute('aria-invalid', 'true');
  if (errorElement) {
    errorElement.textContent = message;
  }
}

function validateForm() {
  let isValid = true;

  const fullName = document.querySelector('#full-name');
  const email = document.querySelector('#email');
  const phone = document.querySelector('#phone');
  const message = document.querySelector('#message');
  const successMessage = document.querySelector('#contact-success');

  if (successMessage) {
    successMessage.textContent = '';
  }

  const fields = [fullName, email, phone, message];
  fields.forEach((field) => clearFieldState(field));

  if (!fullName || !fullName.value.trim()) {
    showFieldError(fullName, 'Please enter your full name.');
    isValid = false;
  }

  const emailValue = email.value.trim();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailValue) {
    showFieldError(email, 'Please enter your email address.');
    isValid = false;
  } else if (!emailPattern.test(emailValue)) {
    showFieldError(email, 'Please enter a valid email address.');
    isValid = false;
  }

  const phoneValue = phone.value.trim();
  if (!phoneValue) {
    showFieldError(phone, 'Please enter your phone number.');
    isValid = false;
  } else if (!/^\d+$/.test(phoneValue)) {
    showFieldError(phone, 'Phone number must contain digits only. Remove spaces, punctuation, or prefixes.');
    isValid = false;
  }

  if (!message || !message.value.trim()) {
    showFieldError(message, 'Please enter a message.');
    isValid = false;
  }

  return { isValid, fields };
}

if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const { isValid } = validateForm();

    if (!isValid) {
      return;
    }

    const successMessage = document.querySelector('#contact-success');
    if (successMessage) {
      successMessage.textContent = 'Your message has been prepared successfully. This is a frontend demonstration only.';
    }

    contactForm.reset();
  });
}
