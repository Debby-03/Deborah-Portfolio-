const projects = [
  {
    title: 'Customer Service Performance Dashboard',
    category: 'Data Analytics',
    description:
      'A sample dashboard designed to track enquiry volume, response time, customer satisfaction, and resolution rates.',
    tech: ['Excel', 'SQL', 'Tableau'],
    photo: 'assets/images/pro1.jpg', // add your own screenshot with this file name
    image: 'assets/images/project-dashboard.svg',
    link: { label: 'View on GitHub', href: 'https://github.com/Debby-03' }, // TODO: replace with the real repo link
    alt: 'Customer service dashboard illustration',
    details: 'A proposed analytical dashboard using sample service data to identify trends and improve operational efficiency.',
    objective: 'Understand customer service performance patterns and highlight improvement opportunities.',
    problem: 'Service teams need a clear view of volume, speed, and satisfaction indicators to make data-informed decisions.',
    tools: 'Excel, SQL, Tableau',
    approach: 'Clean sample data, organize service metrics, and create dashboard views for enquiries, response time, and resolution rates.',
    findings: 'Sample findings highlight areas where response time and satisfaction could be improved by focusing on faster first responses.'
  },
  {
    title: 'Sales and Business Performance Analysis',
    category: 'Business',
    description:
      'A sample retail sales analysis exploring revenue, product performance, order volume, and business trends.',
    tech: ['SQL', 'Excel', 'Google Sheets', 'Tableau'],
    photo: 'assets/images/pro2.jpg', // add your own screenshot with this file name
    image: 'assets/images/project-sales.svg',
    link: { label: 'View on GitHub', href: 'https://github.com/Debby-03' }, // TODO: replace with the real repo link
    alt: 'Retail sales analysis illustration',
    details: 'A business performance review using sample sales data to identify high-performing products and seasonal trends.',
    objective: 'Review business performance and determine which products and periods are driving sales.',
    problem: 'A small retail operation needs a simple method to assess sales trends and improve planning decisions.',
    tools: 'SQL, Excel, Google Sheets, Tableau',
    approach: 'Clean the dataset, group orders by product and period, and visualize patterns across revenue and volume.',
    findings: 'Sample insights show that a few product categories consistently contribute most to monthly revenue and repeat orders.'
  },
  {
    title: 'COS 106 Student Portfolio and Academic Planner',
    category: 'Web Development',
    description:
      'This portfolio website demonstrates semantic HTML, responsive CSS, and JavaScript-driven interactivity.',
    tech: ['HTML5', 'CSS3', 'JavaScript'],
    photo: 'assets/images/pro3.jpg', // add your own screenshot with this file name
    image: 'assets/images/project-portfolio.svg',
    link: { label: 'View source code', href: 'https://github.com/Debby-03' }, // TODO: replace with the portfolio repo link
    alt: 'Student portfolio website placeholder',
    details: 'A responsive portfolio and planner project built as part of the COS 106 term requirement.',
    objective: 'Create a professional website with working navigation, portfolio features, and academic planning tools.',
    problem: 'Students need a polished digital portfolio that shows academic and professional capabilities in a clear, structured format.',
    tools: 'HTML5, CSS3, JavaScript',
    approach: 'Use semantic layout, responsive design, and DOM-based interactions to organize content and improve usability.',
    findings: 'The project demonstrates how structured content, smart planning tools, and accessible design support a strong digital portfolio.'
  }
];

const projectGrid = document.querySelector('#projects-grid');
const filterButtons = document.querySelectorAll('.filter-btn');

function createProjectCard(project) {
  const article = document.createElement('article');
  article.className = 'project-card';

  const image = document.createElement('img');
  image.src = project.photo || project.image;
  image.addEventListener('error', () => {
    if (image.src.indexOf(project.image) === -1) image.src = project.image;
  });
  image.alt = project.alt;

  const body = document.createElement('div');
  body.className = 'card-body';

  const category = document.createElement('span');
  category.className = 'pill';
  category.textContent = project.category;

  const title = document.createElement('h3');
  title.textContent = project.title;

  const description = document.createElement('p');
  description.textContent = project.description;

  const tags = document.createElement('div');
  tags.className = 'skill-grid';
  project.tech.forEach((item) => {
    const tag = document.createElement('span');
    tag.className = 'skill-tag';
    tag.textContent = item;
    tags.appendChild(tag);
  });

  const actions = document.createElement('div');
  actions.className = 'hero-actions';

  const detailsBtn = document.createElement('button');
  detailsBtn.type = 'button';
  detailsBtn.className = 'btn btn-secondary';
  detailsBtn.textContent = 'Project details';
  detailsBtn.setAttribute('aria-expanded', 'false');

  let detailsPanel = null;
  detailsBtn.addEventListener('click', () => {
    if (detailsPanel) {
      detailsPanel.remove();
      detailsPanel = null;
      detailsBtn.textContent = 'Project details';
      detailsBtn.setAttribute('aria-expanded', 'false');
      return;
    }

    detailsPanel = document.createElement('div');
    detailsPanel.className = 'card-body';
    [
      ['Objective', project.objective],
      ['Problem', project.problem],
      ['Tools', project.tools],
      ['Approach', project.approach],
      ['Findings', project.findings]
    ].forEach(([label, text]) => {
      const p = document.createElement('p');
      const strong = document.createElement('strong');
      strong.textContent = `${label}: `;
      p.append(strong, document.createTextNode(text));
      detailsPanel.appendChild(p);
    });
    article.appendChild(detailsPanel);
    detailsBtn.textContent = 'Hide details';
    detailsBtn.setAttribute('aria-expanded', 'true');
  });

  const repoLink = document.createElement('a');
  repoLink.className = 'btn btn-tertiary';
  repoLink.href = project.link.href;
  repoLink.target = '_blank';
  repoLink.rel = 'noreferrer';
  repoLink.textContent = project.link.label;

  actions.append(detailsBtn, repoLink);

  body.append(category, title, description, tags, actions);
  article.append(image, body);
  return article;
}

function renderProjects(filter = 'All') {
  if (!projectGrid) return;

  projectGrid.innerHTML = '';

  const visibleProjects = filter === 'All'
    ? projects
    : projects.filter((project) => project.category === filter);

  visibleProjects.forEach((project) => {
    projectGrid.appendChild(createProjectCard(project));
  });
}

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    filterButtons.forEach((btn) => btn.classList.toggle('active', btn === button));
    renderProjects(button.dataset.filter);
  });
});

renderProjects();
