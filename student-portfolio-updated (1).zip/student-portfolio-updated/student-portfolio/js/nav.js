// Shared behaviour for every page: menu, reveal-on-scroll, progress bars, counters, typing, lightbox
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- Mobile menu ---------- */
const navToggle = document.querySelector('.nav-toggle');
const scrim = document.querySelector('.scrim');

function setMenu(open) {
  document.body.classList.toggle('nav-open', open);
  if (navToggle) navToggle.setAttribute('aria-expanded', String(open));
}

if (navToggle) {
  navToggle.addEventListener('click', () => setMenu(!document.body.classList.contains('nav-open')));
}
if (scrim) scrim.addEventListener('click', () => setMenu(false));
document.querySelectorAll('.side-nav a').forEach((a) => a.addEventListener('click', () => setMenu(false)));

/* ---------- Helpers ---------- */
function countUp(el, target, suffix, duration = 1400, onTick) {
  if (reduceMotion) {
    el.textContent = target + suffix;
    if (onTick) onTick(target);
    return;
  }
  const start = performance.now();
  function frame(now) {
    const t = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - t, 3);
    const value = Math.round(target * eased);
    el.textContent = value + suffix;
    if (onTick) onTick(value);
    if (t < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

function activate(el) {
  if (el.dataset.done) return;
  el.dataset.done = 'true';

  // Skill progress bars
  if (el.classList.contains('bar') && el.dataset.level) {
    const level = Number(el.dataset.level);
    const fill = el.querySelector('.bar-fill');
    const val = el.querySelector('.bar-val');
    if (fill) fill.style.width = `${level}%`;
    if (val) countUp(val, level, '%');
  }

  // Circular rings
  if (el.classList.contains('ring')) {
    const level = Number(el.dataset.level);
    const val = el.querySelector('.ring-val');
    countUp(val, level, '%', 1500, (v) => el.style.setProperty('--p', v));
  }

  // Number counters
  if (el.dataset.count) {
    countUp(el, Number(el.dataset.count), el.dataset.suffix || '', 1600);
  }
}

/* ---------- Reveal + animate when scrolled into view ---------- */
const animated = document.querySelectorAll('.bar[data-level], .ring, [data-count]');
const reveals = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('in');
      activate(entry.target);
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.1 });
  reveals.forEach((el) => observer.observe(el));
  animated.forEach((el) => observer.observe(el));
} else {
  reveals.forEach((el) => el.classList.add('in'));
  animated.forEach(activate);
}

/* ---------- Typing effect on the homepage ---------- */
const typed = document.querySelector('#typed');
if (typed && !reduceMotion) {
  const words = typed.dataset.words.split('|');
  let wordIndex = 0;
  let charIndex = words[0].length;
  let deleting = true;

  function tick() {
    const word = words[wordIndex];
    typed.textContent = word.slice(0, charIndex);

    if (deleting) {
      charIndex -= 1;
      if (charIndex < 0) {
        deleting = false;
        wordIndex = (wordIndex + 1) % words.length;
        charIndex = 0;
      }
      setTimeout(tick, 40);
    } else {
      charIndex += 1;
      if (charIndex > words[wordIndex].length) {
        deleting = true;
        setTimeout(tick, 1800);
        return;
      }
      setTimeout(tick, 80);
    }
  }
  setTimeout(tick, 1800);
}

/* ---------- Lightbox for photos ---------- */
const lightbox = document.createElement('div');
lightbox.className = 'lightbox';
lightbox.setAttribute('role', 'dialog');
lightbox.setAttribute('aria-label', 'Enlarged photo');
const lightboxImg = document.createElement('img');
lightbox.appendChild(lightboxImg);
document.body.appendChild(lightbox);

document.querySelectorAll('.photo-slot img').forEach((img) => {
  img.addEventListener('click', () => {
    lightboxImg.src = img.src;
    lightboxImg.alt = img.alt;
    lightbox.classList.add('open');
  });
});

lightbox.addEventListener('click', () => lightbox.classList.remove('open'));
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    lightbox.classList.remove('open');
    setMenu(false);
  }
});
